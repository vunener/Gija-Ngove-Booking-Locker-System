<?php
session_start();
include 'gijangovelockersystem.php';
include 'sessionManager.php';
requireLogin(['parent', 'admin']);
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: studentRegistration.php");
    exit;
}

// Collect POST data safely
$studentName    = trim($_POST['studentName'] ?? '');
$studentSurname = trim($_POST['studentSurname'] ?? '');
$studentGrade   = ucwords(strtolower(trim($_POST['studentGrade'] ?? '')));
$dateOfBirth    = $_POST['dateOfBirth'] ?? '';
$gender         = $_POST['gender'] ?? '';
$lockerID       = $_POST['lockerID'] ?? null;
$bookingDate    = $_POST['bookingDate'] ?? null;
$parentID       = ($_SESSION['userType'] === 'admin') ? ($_POST['parentID'] ?? null) : $_SESSION['userID'];

// Validation
$errors = [];
if (!$studentName || !$studentSurname || !$dateOfBirth || !$gender || !$studentGrade || !$bookingDate || !$parentID) {
    $errors[] = "All fields are required.";
}

// Booking date validation
$startDate = new DateTime('2026-01-01');
$endDate   = new DateTime('2026-06-30');

try {
    $bookingDateObj = new DateTime($bookingDate);
    if ($bookingDateObj < $startDate || $bookingDateObj > $endDate) {
        $errors[] = "Booking date must be between January 1st and June 30th, 2026.";
    }
} catch (Exception $e) {
    $errors[] = "Invalid booking date format.";
}

// Grade validation
$validGrades = ['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
if (!in_array($studentGrade, $validGrades)) {
    $errors[] = "Invalid grade selected.";
}

if (!empty($errors)) {
    echo "<h2>Registration Failed</h2>";
    foreach ($errors as $error) {
        echo "<p style='color:red;'>" . htmlspecialchars($error) . "</p>";
    }
    echo "<a href='studentRegistration.php'>Go Back</a>";
    exit;
}

try {
    $pdo->beginTransaction();

    // Duplicate student check
    $duplicateCheckStmt = $pdo->prepare(
        "SELECT studentID FROM students WHERE studentName = ? AND studentSurname = ? AND dateOfBirth = ? AND parentID = ?"
    );
    $duplicateCheckStmt->execute([$studentName, $studentSurname, $dateOfBirth, $parentID]);
    if ($duplicateCheckStmt->fetchColumn()) {
        throw new Exception("You cannot add this student, the student is already registered.");
    }

    // Generate new studentSchoolNumber
    $lastStudent = $pdo->query("SELECT MAX(studentSchoolNumber) AS maxNumber FROM students")->fetch();
    $lastNumber = (int)($lastStudent['maxNumber'] ?? 0);
    $newSchoolNumber = str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);

    // Insert student
    $stmt = $pdo->prepare(
        "INSERT INTO students (studentSchoolNumber, studentName, studentSurname, dateOfBirth, gender, studentGrade, parentID, lockerID)
         VALUES (?, ?, ?, ?, ?, ?, ?, NULL)"
    );
    $stmt->execute([$newSchoolNumber, $studentName, $studentSurname, $dateOfBirth, $gender, $studentGrade, $parentID]);
    $studentID = $pdo->lastInsertId();

    // Determine booking status based on grade quota
    $gradeQuota = [
        'Grade 8'  => 10,
        'Grade 9'  => null,
        'Grade 10' => null,
        'Grade 11' => null,
        'Grade 12' => 5,
    ];
    $quota = $gradeQuota[$studentGrade] ?? null;

    $stmt = $pdo->prepare(
        "SELECT COUNT(*) FROM bookings b 
         JOIN students s ON b.studentID = s.studentID 
         WHERE s.studentGrade = ? AND b.status IN ('pending', 'approved')"
    );
    $stmt->execute([$studentGrade]);
    $currentCount = (int)$stmt->fetchColumn();

    $status = ($quota !== null && $currentCount >= $quota) ? 'waiting' : 'pending';

    define('LOCKER_AVAILABLE', 0);
    define('LOCKER_BOOKED', 1);

    // Handle locker assignment
    if ($status === 'pending') {
        // Lock locker row
        $checkLockerStmt = $pdo->prepare("SELECT availability FROM lockers WHERE lockerID = ? FOR UPDATE");
        $checkLockerStmt->execute([$lockerID]);
        $availability = $checkLockerStmt->fetchColumn();

        if ((int)$availability !== 0 && $availability !== 'available') {
            throw new Exception("Locker is no longer available. Please choose a different one.");
        }

        // Insert booking
        $stmt = $pdo->prepare(
            "INSERT INTO bookings (studentID, lockerID, status, bookingDate) VALUES (?, ?, ?, ?)"
        );
        $stmt->execute([$studentID, $lockerID, $status, $bookingDate]);
        $bookingID = $pdo->lastInsertId();

        // Update locker availability
        $updateLockerStmt = $pdo->prepare(
            "UPDATE lockers SET availability = ?, studentGrade = ? WHERE lockerID = ?"
        );
        $updateLockerStmt->execute([LOCKER_BOOKED, $studentGrade, $lockerID]);

        // Update student record
        $stmt = $pdo->prepare("UPDATE students SET lockerID = ? WHERE studentID = ?");
        $stmt->execute([$lockerID, $studentID]);
    } else {
        // Add to waiting list
        $stmt = $pdo->prepare(
            "INSERT INTO waitinglist (studentID, studentGrade, dateAdded, status, type, lockerID)
             VALUES (?, ?, ?, 'Pending', 'Email', NULL)"
        );
        $stmt->execute([$studentID, $studentGrade, date('Y-m-d')]);
        $bookingID = null; // No booking yet
    }

    // Handle payment proof upload if admin
    if ($_SESSION['userType'] === 'admin' && isset($_FILES['paymentProof']) && $_FILES['paymentProof']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/payments/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

        $filename = uniqid('proof_') . '_' . basename($_FILES['paymentProof']['name']);
        $targetPath = $uploadDir . $filename;
        move_uploaded_file($_FILES['paymentProof']['tmp_name'], $targetPath);

        $amount =100.0; // Default amount
        $stmt = $pdo->prepare(
            "INSERT INTO payments (bookingID, amount, paymentDate, status, proofOfPayment) 
             VALUES (?, ?, NOW(), 'pending', ?)"
        );
        $stmt->execute([$bookingID, $amount, $targetPath]);
    }

    // Send notifications
    $adminID = 1; // Replace with session adminID if needed
    $notificationMessage = ($status === 'waiting') 
        ? "Your child $studentName $studentSurname has been added to the locker waiting list."
        : "Your child $studentName $studentSurname has a locker booking pending approval.";

    $stmt = $pdo->prepare(
        "INSERT INTO notifications (parentID, adminID, type, message, dateSent, status, title) 
         VALUES (?, ?, 'Email', ?, NOW(), 'pending', ?)"
    );
    $stmt->execute([$parentID, $adminID, $notificationMessage, ($status === 'waiting' ? 'Student Added to Waiting List' : 'Locker Booking Pending')]);

    // Send email
    $stmt = $pdo->prepare("SELECT parentEmailAddress FROM parents WHERE parentID = ?");
    $stmt->execute([$parentID]);
    $parentEmailAddress = $stmt->fetchColumn();

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'vunenebasa@gmail.com';
        $mail->Password = 'gtmj ytjl gkhi ftbb'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('vunenebasa@gmail.com', 'Administrator');
        $mail->addAddress($parentEmailAddress);
        $mail->isHTML(false);
        $mail->Subject = 'Student Registration Update';
        $mail->Body = ($status === 'waiting')
            ? "Dear Parent,\n\nThank you for registering your child. The student has been added to the waiting list.\n\nPlease submit payment via the portal.\n\nBest regards,\nAdministrator"
            : "Dear Parent,\n\nThank you for registering your child. The locker booking is pending and under review.\n\nYou will receive further communication shortly.\n\nBest regards,\nAdministrator";
        $mail->send();

        // Email to admin
        $mail->clearAddresses();
        $mail->addAddress('vunenebasa@gmail.com');
        $mail->Subject = ($status === 'waiting') ? 'New Student on Waiting List' : 'New Pending Locker Booking';
        $mail->Body = "Student: $studentName $studentSurname\nGrade: $studentGrade\nStatus: $status\n\nPlease review this in the admin panel.";
        $mail->send();

    } catch (Exception $e) {
        error_log("Email error: " . $mail->ErrorInfo);
    }

    $pdo->commit();

    // Redirect to student info page
    header("Location: studentInfo.php?registered=1&studentID=" . urlencode($studentID));
    exit;

} catch (Exception $e) {
    $pdo->rollBack();
    echo "<h2>Error</h2>";
    echo "<p style='color:red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<a href='studentRegistration.php'>Go Back</a>";
}
?>
