<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// timeout session in seconds (30 minutes)
$timeout_duration = 1800;

// to check the session timeout
if (isset($_SESSION['LAST_ACTIVITY']) && (time() - $_SESSION['LAST_ACTIVITY']) > $timeout_duration) {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

//to update last activity time
$_SESSION['LAST_ACTIVITY'] = time();

/**
 * it require user to login 
 */
function requireLogin($requiredUserType = null) {
    // If user not logged in, it redirect to login page
    if (!isset($_SESSION['userType'])) {
        header("Location: login.php");
        exit;
    }

    // If roles are specified, check if user role is allowed
    if ($requiredUserType) {
        if (is_array($requiredUserType)) {
            if (!in_array($_SESSION['userType'], $requiredUserType)) {
                redirectBasedOnRole($_SESSION['userType']);
            }
        } else {
            if ($_SESSION['userType'] !== $requiredUserType) {
                redirectBasedOnRole($_SESSION['userType']);
            }
        }
    }
}

/**
 * to redirect user to their appropriate dashboard
 */
function redirectBasedOnRole($role) {
    switch ($role) {
        case 'admin':
            header("Location: adminDashboard.php");
            break;
        case 'parent':
            header("Location: parentDashboard.php");
            break;
        default:
            header("Location: login.php");
            break;
    }
    exit;
}

/**
 * to get current logged in user
 */
function getUserType() {
    return $_SESSION['userType'] ?? null;
}
?>