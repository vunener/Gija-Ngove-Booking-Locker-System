<?php
session_start();
include 'gijangovelockersystem.php';
include 'sessionManager.php';
requireLogin(['parent', 'admin']);
require 'vendor/autoload.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Only allow POST requests
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: studentRegistration.php");
    exit;
}

// Collect POST data
$studentName    = trim($_POST['studentName'] ?? '');
$studentSurname = trim($_POST['studentSurname'] ?? '');
$studentGrade   = ucwords(strtolower(trim($_POST['studentGrade'] ?? '')));
$dateOfBirth    = $_POST['dateOfBirth'] ?? '';
$gender         = $_POST['gender'] ?? '';
$lockerID       = $_POST['lockerID'] ?? null;
$bookingDate    = $_POST['bookingDate'] ?? null;
$parentID       = ($_SESSION['userType'] === 'admin') ? ($_POST['parentID'] ?? null) : $_SESSION['userID'];

// Validate required fields
$errors = [];
if (!$studentName || !$studentSurname || !$dateOfBirth || !$gender || !$studentGrade || !$bookingDate || !$parentID) {
    $errors[] = "All fields are required.";
}

// Validate booking date
try {
    $bookingDateObj = new DateTime($bookingDate);
    $startDate = new DateTime('2026-01-01');
    $endDate   = new DateTime('2026-06-30');
    if ($bookingDateObj < $startDate || $bookingDateObj > $endDate) {
        $errors[] = "Booking date must be between January 1st and June 30th, 2026.";
    }
} catch (Exception $e) {
    $errors[] = "Invalid booking date format.";
}

// it validate grade
$validGrades = ['Grade 8', 'Grade 9', 'Grade 10', 'Grade 11', 'Grade 12'];
if (!in_array($studentGrade, $validGrades)) {
    $errors[] = "Invalid grade selected.";
}

// Stop if there are validation errors
if (!empty($errors)) {
    echo "<h2>Registration Failed</h2>";
    foreach ($errors as $error) {
        echo "<p style='color:red;'>" . htmlspecialchars($error) . "</p>";
    }
    echo "<a href='studentRegistration.php'>Go Back</a>";
    exit;
}

try {
    $pdo->beginTransaction();

    // it check for duplicate student
    $stmt = $pdo->prepare("SELECT studentID FROM students WHERE studentName = ? AND studentSurname = ? AND dateOfBirth = ? AND parentID = ?");
    $stmt->execute([$studentName, $studentSurname, $dateOfBirth, $parentID]);
    if ($stmt->fetchColumn()) {
        throw new Exception("This student is already registered.");
    }

    // it generate new student school number
    $lastStudent = $pdo->query("SELECT MAX(studentSchoolNumber) AS maxNumber FROM students")->fetch();
    $lastNumber = (int)($lastStudent['maxNumber'] ?? 0);
    $newSchoolNumber = str_pad($lastNumber + 1, 6, '0', STR_PAD_LEFT);

    // Insert student
    $stmt = $pdo->prepare("INSERT INTO students (studentSchoolNumber, studentName, studentSurname, dateOfBirth, gender, studentGrade, parentID, lockerID)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
    );
    $stmt->execute([$newSchoolNumber, $studentName, $studentSurname, $dateOfBirth, $gender, $studentGrade, $parentID, $lockerID]);
    $studentID = $pdo->lastInsertId();

    // it determine booking or waiting list
    $gradeQuota = ['Grade 8'=>10, 'Grade 9'=>null, 'Grade 10'=>null, 'Grade 11'=>null, 'Grade 12'=>5];
    $quota = $gradeQuota[$studentGrade] ?? null;

    // Count all students in this grade who already have bookings pending or approved
    $stmt = $pdo->prepare(" SELECT COUNT(*) 
        FROM students s
        LEFT JOIN bookings b ON s.studentID = b.studentID AND b.status IN ('pending','approved')
        WHERE s.studentGrade = ?
    ");
    $stmt->execute([$studentGrade]);
    $currentCount = (int)$stmt->fetchColumn();


    if ($quota !== null && $currentCount >= $quota) {
        // add to waiting list
        $stmtWaiting = $pdo->prepare("INSERT INTO waitinglist (studentID, studentGrade, lockerID, dateAdded, status, type)
             VALUES (?, ?, ?, NOW(), 'Pending', 'Email')"
        );
        $stmtWaiting->execute([$studentID, $studentGrade, $lockerID]);
        $status = 'waiting';
        $success = true;
        $errorMsg = "Locker quota full for $studentGrade — student added to waiting list.";
    } else {
        // normal booking
        $status = 'pending';
        $randomDate = date('Y-m-d', mt_rand(strtotime('2026-01-01'), strtotime('2026-06-30')));
        $stmtBooking = $pdo->prepare("INSERT INTO bookings (studentID, lockerID, status, bookingDate, comments)
             VALUES (?, ?, 'pending', ?, ?)"
        );
        $stmtBooking->execute([$studentID, $lockerID, $randomDate, "Your booking is pending approval."]);

        // update locker availability
        if ($lockerID) {
            $stmtUpdate = $pdo->prepare("UPDATE lockers SET availability = 1, studentGrade = ? WHERE lockerID = ?");
            $stmtUpdate->execute([$studentGrade, $lockerID]);
        }
        $success = true;
    }

    // to handle payment upload 
    if ($_SESSION['userType'] === 'admin' && isset($_FILES['paymentProof']) && $_FILES['paymentProof']['error'] === UPLOAD_ERR_OK) {
        $uploadDir = 'uploads/payments/';
        if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);
        $filename = uniqid('proof_') . '_' . basename($_FILES['paymentProof']['name']);
        $targetPath = $uploadDir . $filename;
        move_uploaded_file($_FILES['paymentProof']['tmp_name'], $targetPath);

        $amount = 100.00;
        $stmt = $pdo->prepare("INSERT INTO payments (bookingID, amount, paymentDate, status, proofOfPayment) VALUES (?, ?, NOW(), 'pending', ?)");
        $stmt->execute([$bookingID ?? null, $amount, $targetPath]);
    }

    // Notifications
    $adminID = 1;
    $notificationMessage = ($status === 'waiting')
        ? "The student $studentName $studentSurname has been added to the locker waiting list."
        : "The student $studentName $studentSurname has a locker booking pending approval.";

    $stmtNotif = $pdo->prepare("INSERT INTO notifications (parentID, adminID, type, message, dateSent, status, title)
         VALUES (?, ?, 'Email', ?, NOW(), 'pending', ?)"
    );
    $stmtNotif->execute([$parentID, $adminID, $notificationMessage,
        ($status === 'waiting') ? 'Student Added to Waiting List' : 'Locker Booking Pending'
    ]);

    // send email
    $stmt = $pdo->prepare("SELECT parentEmailAddress FROM parents WHERE parentID = ?");
    $stmt->execute([$parentID]);
    $parentEmail = $stmt->fetchColumn();

    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host       = 'smtp.gmail.com';
        $mail->SMTPAuth   = true;
        $mail->Username   = 'vunenebasa@gmail.com';
        $mail->Password   = 'gtmj ytjl gkhi ftbb'; 
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port       = 587;

        // email to parent
        $mail->setFrom('vunenebasa@gmail.com', 'Administrator');
        $mail->addAddress($parentEmail);
        $mail->isHTML(false);
        $mail->Subject = 'Student Registration Update';
        $mail->Body = ($status === 'waiting')
            ? "Dear Parent,\n\nYour child has been added to the waiting list.\n\nPlease submit payment via the portal.\n\nBest regards,\nAdministrator"
            : "Dear Parent,\n\nYour child's locker booking is pending review.\n\nBest regards,\nAdministrator";
        $mail->send();

        // email to admin
        $mail->clearAddresses();
        $mail->addAddress('vunenebasa@gmail.com');
        $mail->Subject = ($status === 'waiting') ? 'New Student on Waiting List' : 'New Pending Locker Booking';
        $mail->Body = "Student: $studentName $studentSurname\nGrade: $studentGrade\nStatus: $status\n\nPlease review in admin panel.";
        $mail->send();

    } catch (Exception $e) {
        error_log("Email error: " . $mail->ErrorInfo);
    }

    $pdo->commit();

    header("Location: studentInfo.php?registered=1&studentID=" . urlencode($studentID));
    exit;

} catch (Exception $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    echo "<h2>Error</h2>";
    echo "<p style='color:red;'>" . htmlspecialchars($e->getMessage()) . "</p>";
    echo "<a href='studentRegistration.php'>Go Back</a>";
}
