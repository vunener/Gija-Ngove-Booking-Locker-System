<?php

/**
 * to fetch parent details by username.
 */
function getParentByUsername(PDO $pdo, string $username) {
    $stmt = $pdo->prepare("SELECT * FROM parents WHERE parentUsername = ?");
    $stmt->execute([$username]);
    return $stmt->fetch(PDO::FETCH_ASSOC);
}

/**
 * to count bookings by status.
 */
function getBookingCountByStatus($pdo, $status) {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings WHERE TRIM(LOWER(status)) = ?");
    $stmt->execute([strtolower(trim($status))]);
    return (int)$stmt->fetchColumn();
}


/**
 * to count bookings between two dates with a given status.
*/
function getBookingCountBetweenDates(PDO $pdo, string $status, string $startDate, string $endDate): int {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM bookings 
        WHERE TRIM(LOWER(status)) = ? AND bookingDate BETWEEN ? AND ?");
    $stmt->execute([strtolower(trim($status)), $startDate, $endDate]);
    return (int) $stmt->fetchColumn();
}


/**
 * to send an email to notify parent they are on the waiting list.
 */
function sendWaitingEmail(string $parentEmail): void {
    if (filter_var($parentEmail, FILTER_VALIDATE_EMAIL)) {
        $subject = "Locker Application Waiting Notification";
        $message = "Dear Parent,\n\nYour locker application is currently in waiting. We will notify you once a locker is available.\n\nThank you.";
        $headers = "From: vunenebasa@gmail.com\r\nContent-Type: text/plain; charset=UTF-8";
        mail($parentEmail, $subject, $message, $headers);
    }
}

/**
 * it automatically update bookings from 'approved' to 'complete' 
 */
function autoCompleteBookings(PDO $pdo): void {
    $simulatedToday = '2026-06-01';  
    $stmt = $pdo->prepare("UPDATE bookings 
        SET status = 'complete' 
        WHERE status = 'approved' AND bookingDate < ?
    ");
    $stmt->execute([$simulatedToday]);
}
/** 
 * Once it's the year 2026, this function must be activated. 
function autoCompleteBookings(PDO $pdo): void {
    $stmt = $pdo->prepare("UPDATE bookings 
        SET status = 'complete' 
        WHERE status = 'approved' AND bookingDate < CURDATE()
    ");
    $stmt->execute();
}

*/

/**
 * to send a payment request email to the parent.
 */
function sendPaymentRequestEmail(string $parentEmail, int $bookingID): void {
    if (filter_var($parentEmail, FILTER_VALIDATE_EMAIL)) {
        $subject = "Locker Payment Request";
        $message = "Dear Parent,\n\nYour locker has been allocated. Please make the payment for booking #$bookingID.\n\nAttach your proof of payment after completing payment.\n\nThank you.";
        $headers = "From: vunenebasa@gmail.com\r\nContent-Type: text/plain; charset=UTF-8";
        mail($parentEmail, $subject, $message, $headers);
    }
}

/**
 * to get number of parents currently on the waiting list.
 */
function getWaitingListCount(PDO $pdo): int {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM waitinglist WHERE LOWER(status) = 'waiting'");
    $stmt->execute();
    return (int) $stmt->fetchColumn();
}

/**
 * to get number of pending notifications.
 */
function getNotificationCount(PDO $pdo): int {
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE LOWER(status) = 'pending'");
    $stmt->execute();
    return (int) $stmt->fetchColumn();
}

?>